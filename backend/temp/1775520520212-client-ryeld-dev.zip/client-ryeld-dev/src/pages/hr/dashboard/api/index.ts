// API services - Implementation pending
